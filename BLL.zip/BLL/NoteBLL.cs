﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class NoteBLL
    {
        public int id_note { get; set; }
        public float valeur{ get; set; }
        public int id_mat{ get; set; }
        public int id_Etudiant { get; set; }

      
    }
}
