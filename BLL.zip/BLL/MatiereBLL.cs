﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class MatiereBLL
    {
        public int id_mat { get; set; }
        public string nom { get; set; }
        public int credit { get; set; }
        public string description { get; set; }
       
    }
}
