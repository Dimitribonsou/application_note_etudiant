﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class FiliereBLL
    {
        public int id_filiere { get; set; }
        public string nom { get; set; }
        public string libelle { get; set; }
        public string description{ get; set;}

    }
}
