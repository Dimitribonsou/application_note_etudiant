﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class classe_matBLL
    {
        public int id_classe_mat { get; set; }
        public int id_classe{ get; set; }
        public int id_mat { get; set; }
    }
}
