﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ClasseBLL
    {
        public int id_classe { get; set; }
        public string nom { get; set; }
        public string libelle { get; set; }
        public int niveau { get; set; }
        public int id_filiere { get; set;}
    }
}
