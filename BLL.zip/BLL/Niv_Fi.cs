﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class Niv_Fi
    {
        public int id_niv_Fi { get; set; }
        public int id_niv { get; set; }
        public int id_filiere{ get; set; }
    }
}
